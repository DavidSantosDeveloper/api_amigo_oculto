package com.amigo_oculto.api.interface_adapters.repositories;
import com.amigo_oculto.api.interface_adapters.repositories.*;


import org.springframework.data.jpa.repository.JpaRepository;

public interface InterfaceSorteioJpaRepository extends JpaRepository<SorteioEntity, Long> {
}